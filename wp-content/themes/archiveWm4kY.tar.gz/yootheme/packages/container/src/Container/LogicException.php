<?php

namespace YOOtheme\Container;

use Psr\Container\ContainerExceptionInterface;

class LogicException extends \LogicException implements ContainerExceptionInterface {}
