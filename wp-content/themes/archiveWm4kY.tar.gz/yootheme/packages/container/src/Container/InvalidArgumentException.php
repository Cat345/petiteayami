<?php

namespace YOOtheme\Container;

use Psr\Container\ContainerExceptionInterface;

class InvalidArgumentException extends \InvalidArgumentException implements
    ContainerExceptionInterface {}
