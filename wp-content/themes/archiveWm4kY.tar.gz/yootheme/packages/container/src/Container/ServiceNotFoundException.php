<?php

namespace YOOtheme\Container;

use Psr\Container\NotFoundExceptionInterface;

class ServiceNotFoundException extends \InvalidArgumentException implements
    NotFoundExceptionInterface {}
