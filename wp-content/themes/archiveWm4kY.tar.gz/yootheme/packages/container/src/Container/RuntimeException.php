<?php

namespace YOOtheme\Container;

use Psr\Container\ContainerExceptionInterface;

class RuntimeException extends \RuntimeException implements ContainerExceptionInterface {}
