<?php declare(strict_types=1);

namespace YOOtheme\GraphQL\Server\Exception;

use YOOtheme\GraphQL\Server\RequestError;

class CannotParseVariables extends RequestError {}
