<?php declare(strict_types=1);

namespace YOOtheme\GraphQL\Language;

abstract class VisitorOperation {}
