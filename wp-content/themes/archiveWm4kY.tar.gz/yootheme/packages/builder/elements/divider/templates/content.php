<?php if ($props['divider_element'] == 'hr') : ?>
<hr>
<?php endif ?>
