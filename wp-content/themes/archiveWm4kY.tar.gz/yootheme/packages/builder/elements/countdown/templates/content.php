<?php if ($props['date']) : ?>
<time datetime="<?= $props['date'] ?>"><?= $props['date'] ?></time>
<?php endif ?>
