<?php if ($props['content'] != '') : ?>
<div>

    <?= $props['content'] ?>

</div>
<?php endif ?>
