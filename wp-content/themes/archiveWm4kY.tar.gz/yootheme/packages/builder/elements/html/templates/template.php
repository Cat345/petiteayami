<?php

$el = $this->el('div');

echo $el($props, $attrs, $props['content']);
