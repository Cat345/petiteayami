<?php
/**
 * This dummy sidebar file is needed for WooCommerce.
 */
